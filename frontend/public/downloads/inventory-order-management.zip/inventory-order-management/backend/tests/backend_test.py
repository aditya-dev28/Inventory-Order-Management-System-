"""Pytest suite for Inventory & Order Management API.

Covers:
- Dashboard stats
- Product CRUD with SKU uniqueness, negative validation
- Customer CRUD with unique email & invalid email/phone
- Multi-product Order creation, stock deduction, restore-on-delete
- Edge cases (404, 409, 422)
"""
import os
import uuid
import pytest
import requests

BASE_URL = os.environ.get("REACT_APP_BACKEND_URL", "https://product-order-ops.preview.emergentagent.com").rstrip("/")
API = f"{BASE_URL}/api"


@pytest.fixture(scope="session")
def session():
    s = requests.Session()
    s.headers.update({"Content-Type": "application/json"})
    return s


def _unique(prefix: str) -> str:
    return f"{prefix}_{uuid.uuid4().hex[:8]}"


# ---------- Health & Dashboard ----------
class TestDashboard:
    def test_health(self, session):
        r = session.get(f"{API}/health")
        assert r.status_code == 200
        assert r.json()["status"] == "healthy"

    def test_dashboard_stats(self, session):
        r = session.get(f"{API}/dashboard/stats")
        assert r.status_code == 200
        data = r.json()
        for k in ["total_products", "total_customers", "total_orders", "low_stock_products", "low_stock_threshold"]:
            assert k in data, f"Missing key: {k}"
        assert data["low_stock_threshold"] == 10
        assert isinstance(data["total_products"], int)
        assert data["total_products"] >= 10
        assert data["total_customers"] >= 6


# ---------- Products ----------
class TestProducts:
    def test_list_products(self, session):
        r = session.get(f"{API}/products")
        assert r.status_code == 200
        items = r.json()
        assert isinstance(items, list)
        assert len(items) >= 10
        skus = {p["sku_code"] for p in items}
        assert "WM-001" in skus

    def test_create_product_success(self, session):
        sku = _unique("TEST-SKU")
        payload = {"product_name": "TEST_Widget", "sku_code": sku, "price": 199.50, "quantity_in_stock": 25}
        r = session.post(f"{API}/products", json=payload)
        assert r.status_code == 201, r.text
        d = r.json()
        assert d["sku_code"] == sku
        assert d["product_name"] == "TEST_Widget"
        assert float(d["price"]) == 199.50
        pid = d["id"]
        # GET verification
        g = session.get(f"{API}/products/{pid}")
        assert g.status_code == 200
        assert g.json()["sku_code"] == sku
        # cleanup
        session.delete(f"{API}/products/{pid}")

    def test_create_product_duplicate_sku(self, session):
        sku = _unique("TEST-DUP")
        p1 = session.post(f"{API}/products", json={"product_name": "TEST_A", "sku_code": sku, "price": 10, "quantity_in_stock": 1})
        assert p1.status_code == 201
        p2 = session.post(f"{API}/products", json={"product_name": "TEST_B", "sku_code": sku, "price": 11, "quantity_in_stock": 2})
        assert p2.status_code == 409
        session.delete(f"{API}/products/{p1.json()['id']}")

    def test_create_product_negative_price(self, session):
        r = session.post(f"{API}/products", json={"product_name": "TEST_Neg", "sku_code": _unique("TEST-N"), "price": -1, "quantity_in_stock": 5})
        assert r.status_code == 422

    def test_create_product_negative_qty(self, session):
        r = session.post(f"{API}/products", json={"product_name": "TEST_Neg2", "sku_code": _unique("TEST-N2"), "price": 5, "quantity_in_stock": -1})
        assert r.status_code == 422

    def test_get_product_not_found(self, session):
        r = session.get(f"{API}/products/999999")
        assert r.status_code == 404

    def test_update_product(self, session):
        sku = _unique("TEST-UP")
        c = session.post(f"{API}/products", json={"product_name": "TEST_U", "sku_code": sku, "price": 100, "quantity_in_stock": 10})
        pid = c.json()["id"]
        u = session.put(f"{API}/products/{pid}", json={"price": 150, "quantity_in_stock": 20})
        assert u.status_code == 200
        assert float(u.json()["price"]) == 150
        g = session.get(f"{API}/products/{pid}")
        assert float(g.json()["price"]) == 150
        assert g.json()["quantity_in_stock"] == 20
        session.delete(f"{API}/products/{pid}")

    def test_delete_product(self, session):
        c = session.post(f"{API}/products", json={"product_name": "TEST_D", "sku_code": _unique("TEST-D"), "price": 1, "quantity_in_stock": 0})
        pid = c.json()["id"]
        d = session.delete(f"{API}/products/{pid}")
        assert d.status_code == 200
        assert session.get(f"{API}/products/{pid}").status_code == 404


# ---------- Customers ----------
class TestCustomers:
    def test_list_customers(self, session):
        r = session.get(f"{API}/customers")
        assert r.status_code == 200
        assert len(r.json()) >= 6

    def test_create_customer_success(self, session):
        email = f"test_{uuid.uuid4().hex[:8]}@example.in"
        r = session.post(f"{API}/customers", json={"full_name": "TEST_Customer", "email": email, "phone_number": "+91 90000 00000"})
        assert r.status_code == 201, r.text
        d = r.json()
        assert d["email"] == email
        cid = d["id"]
        assert session.get(f"{API}/customers/{cid}").status_code == 200
        session.delete(f"{API}/customers/{cid}")

    def test_create_customer_duplicate_email(self, session):
        email = f"dup_{uuid.uuid4().hex[:8]}@example.in"
        r1 = session.post(f"{API}/customers", json={"full_name": "TEST_A", "email": email, "phone_number": "+91 90000 11111"})
        assert r1.status_code == 201
        r2 = session.post(f"{API}/customers", json={"full_name": "TEST_B", "email": email, "phone_number": "+91 90000 22222"})
        assert r2.status_code == 409
        session.delete(f"{API}/customers/{r1.json()['id']}")

    def test_invalid_email(self, session):
        r = session.post(f"{API}/customers", json={"full_name": "TEST_Bad", "email": "not-an-email", "phone_number": "+91 90000 33333"})
        assert r.status_code == 422

    def test_invalid_phone(self, session):
        r = session.post(f"{API}/customers", json={"full_name": "TEST_Bad", "email": f"ok_{uuid.uuid4().hex[:6]}@example.in", "phone_number": "abc"})
        assert r.status_code == 422

    def test_customer_not_found(self, session):
        assert session.get(f"{API}/customers/999999").status_code == 404


# ---------- Orders ----------
class TestOrders:
    @pytest.fixture(scope="class")
    def seed_data(self, session):
        # use existing seeded customer 1 (Rahul Sharma) and create dedicated products
        cust = session.get(f"{API}/customers").json()
        customer_id = cust[-1]["id"]  # use first seeded
        # Create two test products with known stock
        p1 = session.post(f"{API}/products", json={"product_name": "TEST_OrderProd1", "sku_code": _unique("TEST-OP1"), "price": 100, "quantity_in_stock": 20}).json()
        p2 = session.post(f"{API}/products", json={"product_name": "TEST_OrderProd2", "sku_code": _unique("TEST-OP2"), "price": 250, "quantity_in_stock": 15}).json()
        yield {"customer_id": customer_id, "p1": p1, "p2": p2}
        # cleanup products (may fail if referenced - okay)
        session.delete(f"{API}/products/{p1['id']}")
        session.delete(f"{API}/products/{p2['id']}")

    def test_create_order_multi_product(self, session, seed_data):
        p1, p2 = seed_data["p1"], seed_data["p2"]
        payload = {
            "customer_id": seed_data["customer_id"],
            "items": [
                {"product_id": p1["id"], "quantity": 2},
                {"product_id": p2["id"], "quantity": 3},
            ],
        }
        r = session.post(f"{API}/orders", json=payload)
        assert r.status_code == 201, r.text
        d = r.json()
        expected_total = 100 * 2 + 250 * 3
        assert float(d["total_amount"]) == float(expected_total)
        assert len(d["items"]) == 2
        # Stock reduced
        s1 = session.get(f"{API}/products/{p1['id']}").json()
        s2 = session.get(f"{API}/products/{p2['id']}").json()
        assert s1["quantity_in_stock"] == 20 - 2
        assert s2["quantity_in_stock"] == 15 - 3
        order_id = d["id"]

        # Detail
        det = session.get(f"{API}/orders/{order_id}")
        assert det.status_code == 200
        ditem = det.json()["items"][0]
        for k in ["product_name", "sku_code", "quantity", "price_at_purchase", "line_total"]:
            assert k in ditem

        # Delete restores stock
        d2 = session.delete(f"{API}/orders/{order_id}")
        assert d2.status_code == 200
        s1b = session.get(f"{API}/products/{p1['id']}").json()
        s2b = session.get(f"{API}/products/{p2['id']}").json()
        assert s1b["quantity_in_stock"] == 20
        assert s2b["quantity_in_stock"] == 15
        # Already deleted
        assert session.get(f"{API}/orders/{order_id}").status_code == 404

    def test_order_customer_not_found(self, session, seed_data):
        r = session.post(f"{API}/orders", json={"customer_id": 999999, "items": [{"product_id": seed_data["p1"]["id"], "quantity": 1}]})
        assert r.status_code == 404

    def test_order_product_not_found(self, session, seed_data):
        r = session.post(f"{API}/orders", json={"customer_id": seed_data["customer_id"], "items": [{"product_id": 999999, "quantity": 1}]})
        assert r.status_code == 404

    def test_order_insufficient_stock(self, session, seed_data):
        p1 = seed_data["p1"]
        # request way more than stock
        r = session.post(f"{API}/orders", json={"customer_id": seed_data["customer_id"], "items": [{"product_id": p1["id"], "quantity": 99999}]})
        assert r.status_code == 409
        assert "stock" in r.text.lower() or "insufficient" in r.text.lower()

    def test_order_invalid_quantity(self, session, seed_data):
        r = session.post(f"{API}/orders", json={"customer_id": seed_data["customer_id"], "items": [{"product_id": seed_data["p1"]["id"], "quantity": 0}]})
        assert r.status_code == 422
        r2 = session.post(f"{API}/orders", json={"customer_id": seed_data["customer_id"], "items": [{"product_id": seed_data["p1"]["id"], "quantity": -1}]})
        assert r2.status_code == 422

    def test_order_aggregates_duplicate_product(self, session, seed_data):
        p1 = seed_data["p1"]
        before = session.get(f"{API}/products/{p1['id']}").json()["quantity_in_stock"]
        payload = {
            "customer_id": seed_data["customer_id"],
            "items": [
                {"product_id": p1["id"], "quantity": 2},
                {"product_id": p1["id"], "quantity": 3},
            ],
        }
        r = session.post(f"{API}/orders", json=payload)
        assert r.status_code == 201
        d = r.json()
        assert len(d["items"]) == 1  # aggregated
        assert d["items"][0]["quantity"] == 5
        after = session.get(f"{API}/products/{p1['id']}").json()["quantity_in_stock"]
        assert after == before - 5
        # cleanup
        session.delete(f"{API}/orders/{d['id']}")

    def test_order_not_found(self, session):
        assert session.get(f"{API}/orders/999999").status_code == 404
        assert session.delete(f"{API}/orders/999999").status_code == 404

    def test_list_orders(self, session):
        r = session.get(f"{API}/orders")
        assert r.status_code == 200
        assert isinstance(r.json(), list)

    def test_delete_referenced_product_returns_409(self, session, seed_data):
        # create a fresh order, then try to delete referenced product
        p1 = seed_data["p1"]
        o = session.post(f"{API}/orders", json={"customer_id": seed_data["customer_id"], "items": [{"product_id": p1["id"], "quantity": 1}]})
        assert o.status_code == 201
        order_id = o.json()["id"]
        d = session.delete(f"{API}/products/{p1['id']}")
        assert d.status_code == 409
        # cleanup
        session.delete(f"{API}/orders/{order_id}")

    def test_delete_customer_with_orders_returns_409(self, session, seed_data):
        p1 = seed_data["p1"]
        o = session.post(f"{API}/orders", json={"customer_id": seed_data["customer_id"], "items": [{"product_id": p1["id"], "quantity": 1}]})
        assert o.status_code == 201
        d = session.delete(f"{API}/customers/{seed_data['customer_id']}")
        assert d.status_code == 409
        # cleanup
        session.delete(f"{API}/orders/{o.json()['id']}")
